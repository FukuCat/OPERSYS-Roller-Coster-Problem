import action.*;
import model.Data;
import utils.Debug;

import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class Main {
	
	//OPERSYS S17 Fukuoka, Reodica, Syfu

    private static int MAX_PASSENGERS = 500;
    private static ArrayList<Thread> pList = new ArrayList<>();


    public static void main(String[] args) {
        new Demo().start();
    }



}
