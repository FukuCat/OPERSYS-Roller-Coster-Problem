package action;

public interface DemoThread {
public void quit();
}
