[OPERSYS S17] Fukuoka, Reodica, Syfu

Simply run the main function and follow the steps in console to run